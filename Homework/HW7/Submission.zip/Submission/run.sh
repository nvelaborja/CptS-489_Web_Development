node server.js /Users/nathan/Documents/School/WSU/Computer\ Science/CptS-489_Web_Development/Homework/HW7

